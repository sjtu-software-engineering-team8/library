from django.db import models

# Create your models here.
class Question(models.Model):
    question_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField('date published')
    def __str__(self):
        return self.question_text


class Choice(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    choice_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)
    def __str__(self):
        return self.choice_text

class desk(models.Model):
    desk_number = models.CharField(primary_key=True,max_length=5)
    floor = models.CharField(max_length=1)
    plug_state = models.BooleanField()

class rent(models.Model):
    user_number = models.CharField(primary_key=True,max_length=5)
    start_time = models.IntegerField()
    end_time = models.IntegerField()
    desk_number = models.ForeignKey(desk,on_delete=models.CASCADE)

