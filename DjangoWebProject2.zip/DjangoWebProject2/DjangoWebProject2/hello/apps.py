from django.apps import AppConfig


class helloConfig(AppConfig):
    name = 'hello'
