from django.http import HttpResponse

# Create your views here.
def hello(request):
    return HttpResponse("hello world!");

def test(request):
    return HttpResponse("test");

#def choice(request):
#    name = models.choice.votes.get(id=1);
#    return HttpResponse("test");
